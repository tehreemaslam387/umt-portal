package com.example.umtportal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class CreateNewAccount extends AppCompatActivity {

    TextView textBacktoLogin;

    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    Button btnRegister;
    EditText etEmail,etPass,etcPass;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_new_account);
        textBacktoLogin = findViewById(R.id.login);
        btnRegister = findViewById(R.id.regBtn);
        etEmail = findViewById(R.id.email);
        etPass = findViewById(R.id.pass);
        etcPass = findViewById(R.id.cpass);
        preferences = getSharedPreferences("uni", MODE_PRIVATE);
        editor = preferences.edit();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        textBacktoLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreateNewAccount.this, MainActivity.class);
                startActivity(intent);
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                        String email    = etEmail.getText().toString();
                        String pass  = etPass.getText().toString();
                        String repass = etcPass.getText().toString();

                        if(email.isEmpty() || pass.isEmpty()|| repass.isEmpty()){
                            Toast.makeText(CreateNewAccount.this,"All fields are mandatory",Toast.LENGTH_LONG).show();
                        }else if (!email.contains("@") || !email.contains(".com")){
                            Toast.makeText(CreateNewAccount.this,"Enter proper email",Toast.LENGTH_LONG).show();
                        }else if(!pass.equals(repass)){
                            Toast.makeText(CreateNewAccount.this,"Passwords are not same",Toast.LENGTH_LONG).show();
                        }else if(pass.length() < 8){
                            Toast.makeText(CreateNewAccount.this,"Passwords should be of 8 characters",Toast.LENGTH_LONG).show();
                        }else{

                            editor.putString("email",email).commit();
                            editor.putString("pass",pass).commit();
                            editor.putBoolean("isRegistered", true).commit();
                            Toast.makeText(CreateNewAccount.this,"Successful",Toast.LENGTH_LONG).show();
                            finish();
                        }

            }
        });
    }
}