package com.example.umtportal;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class needhelp extends AppCompatActivity {
    ImageView ivProfile;
    ImageView notificationdialouge;
    ImageView messagedialouge;
    Button addappointment;
    Button advisorrbtn;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_needhelp);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ivProfile = findViewById(R.id.profile);
        notificationdialouge = findViewById(R.id.notification);
        messagedialouge = findViewById(R.id.message1);
        addappointment = findViewById(R.id.appointment);
        advisorrbtn = findViewById(R.id.your_advisor);

        ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(needhelp.this);
                View vv = LayoutInflater.from(needhelp.this).inflate(R.layout.layout_profile_dialog,null);

                TextView dialougelogout = vv.findViewById(R.id.profile_logout);
                dialougelogout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        finish();
                    }
                });

                dialog.setContentView(vv);
                dialog.show();

            }
        });

        notificationdialouge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(needhelp.this);
                View vu = LayoutInflater.from(needhelp.this).inflate(R.layout.notification,null);

                dialog.setContentView(vu);
                dialog.show();
            }

        });

        messagedialouge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(needhelp.this);
                View vv = LayoutInflater.from(needhelp.this).inflate(R.layout.messages, null);

                dialog.setContentView(vv);
                dialog.show();
            }
        });

        addappointment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(needhelp.this);
                View vv = LayoutInflater.from(needhelp.this).inflate(R.layout.set_appointment, null);

                dialog.setContentView(vv);
                dialog.show();
            }
        });

        advisorrbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(needhelp.this, studentadvisor.class);
                startActivity(intent);
            }
        });
    }
}