package com.example.umtportal;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class myProfile extends AppCompatActivity {

    boolean isTimeTableVisible = false;
    LinearLayout timetableCon;
    Button btnTimeTable;
    ImageView ivProfile;
    ImageView notificationdialouge;
    ImageView messagedialouge;
    boolean isRegisterationVisible = false;
    LinearLayout registerationCon;
    Button btnRegisteration;
    Button registeration;
    Button attendancee;
    Button mycourses;
    Button studntadvisor;
    Button lmsss;
    Button Shortattndnce;

    static boolean isLogout = false;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_my_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnTimeTable = findViewById(R.id.timetable1Btn);
        timetableCon = findViewById(R.id.table1Con);
        ivProfile = findViewById(R.id.profile);
        notificationdialouge = findViewById(R.id.notification);
        messagedialouge = findViewById(R.id.message1);
        btnRegisteration = findViewById(R.id.regBtn);
        registerationCon = findViewById(R.id.registerationCon);
        registeration = findViewById(R.id.registerations);
        attendancee = findViewById(R.id.attendance);
        mycourses = findViewById(R.id.my_course);
        studntadvisor = findViewById(R.id.student_advisor);
        lmsss = findViewById(R.id.lms);
        Shortattndnce = findViewById(R.id.short_attendance);


        btnTimeTable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(isTimeTableVisible == false){
                    isTimeTableVisible = true;
                    timetableCon.setVisibility(View.VISIBLE);
                }else{
                    isTimeTableVisible = false;
                    timetableCon.setVisibility(View.GONE);
                }

            }
        });
        btnRegisteration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(isRegisterationVisible == false){
                    isRegisterationVisible = true;
                    registerationCon.setVisibility(View.VISIBLE);
                }else{
                    isRegisterationVisible = false;
                    registerationCon.setVisibility(View.GONE);
                }
            }
        });

        ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                  Dialog dialog = new Dialog(myProfile.this);
                  View vv = LayoutInflater.from(myProfile.this).inflate(R.layout.layout_profile_dialog,null);

                TextView dialougelogout = vv.findViewById(R.id.profile_logout);
                dialougelogout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        finish();
                    }
                });

                  dialog.setContentView(vv);
                  dialog.show();

            }
        });

        notificationdialouge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(myProfile.this);
                View vu = LayoutInflater.from(myProfile.this).inflate(R.layout.notification,null);

                dialog.setContentView(vu);
                dialog.show();
            }

        });

        messagedialouge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(myProfile.this);
                View vv = LayoutInflater.from(myProfile.this).inflate(R.layout.messages, null);

                dialog.setContentView(vv);
                dialog.show();
            }
        });

        registeration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(myProfile.this, com.example.umtportal.registeration.class);
                startActivity(intent);
            }
        });
        attendancee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(myProfile.this,attendance.class );
                startActivity(intent);
            }
        });
        mycourses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(myProfile.this,mycourse.class);
                startActivity(intent);
            }
        });
        studntadvisor.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
           Intent intent = new Intent(myProfile.this,studentadvisor.class);
           startActivity(intent);
           }
});
        lmsss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(myProfile.this,lms.class);
                startActivity(intent);
            }
        });
Shortattndnce.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(myProfile.this,shortattendance.class);
        startActivity(intent);
    }
});




    }


    @Override
    protected void onResume() {
        super.onResume();

        if(isLogout == true){
            isLogout = false;
            finish();
        }
    }
}