package com.example.umtportal;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class registeration extends AppCompatActivity {

    ImageView ivProfile;
    ImageView notificationdialouge;
    ImageView messagedialouge;
    ImageView menuubarr;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registeration);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        ivProfile = findViewById(R.id.profile);
        notificationdialouge = findViewById(R.id.notification);
        messagedialouge = findViewById(R.id.message1);
        menuubarr = findViewById(R.id.registeration_menu);

        ivProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(registeration.this);
                View vv = LayoutInflater.from(registeration.this).inflate(R.layout.layout_profile_dialog,null);

                TextView dialougelogout = vv.findViewById(R.id.profile_logout);
                dialougelogout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        myProfile.isLogout = true;
                        finish();
                    }
                });

                dialog.setContentView(vv);
                dialog.show();

            }
        });

        notificationdialouge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(registeration.this);
                View vu = LayoutInflater.from(registeration.this).inflate(R.layout.notification,null);

                dialog.setContentView(vu);
                dialog.show();
            }

        });

        messagedialouge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(registeration.this);
                View vv = LayoutInflater.from(registeration.this).inflate(R.layout.messages, null);

                dialog.setContentView(vv);
                dialog.show();
            }
        });
        menuubarr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(registeration.this,myProfile.class);
                startActivity(intent);
            }
        });

    }
}