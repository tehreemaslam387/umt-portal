package com.example.umtportal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView textCreateNewAccount;
    TextView textForgotPassword;
    TextView textAlumniAccess;
    Button signinbtn;
    EditText email;
    EditText passw;
    EditText Code;

    SharedPreferences preferences;
    SharedPreferences.Editor editor;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EdgeToEdge.enable(this);

        preferences = getSharedPreferences("uni", MODE_PRIVATE);
        editor = preferences.edit();


        String savedEmail = preferences.getString("email","null");
        String savedPass = preferences.getString("pass","null");



        textCreateNewAccount = findViewById(R.id.text1);
        textForgotPassword = findViewById(R.id.text2);
        textAlumniAccess = findViewById(R.id.text3);
        signinbtn = findViewById(R.id.signin);
        email = findViewById(R.id.student_email);
        passw = findViewById(R.id.student_password);
        Code = findViewById(R.id.code);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        textCreateNewAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CreateNewAccount.class);
                startActivity(intent);


            }
        });
        textForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ForgotPassword.class);
                startActivity(intent);
            }
        });
        textAlumniAccess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this, AlumniAccess.class);
                startActivity(intent);
            }
        });
        signinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String studentemail = email.getText().toString().trim();
                String password = passw.getText().toString().trim();
                String code = Code.getText().toString().trim();

                if(studentemail.isEmpty() || password.isEmpty() || code.isEmpty()){
                    Toast.makeText(MainActivity.this,"All fields are mandatory",Toast.LENGTH_LONG).show();
                } else if (!studentemail.contains("@") || !studentemail.contains(".com")) {
                    Toast.makeText(MainActivity.this,"Enter proper email",Toast.LENGTH_LONG).show();
                } else if(password.length() < 8){
                    Toast.makeText(MainActivity.this,"Passwords should be of 8 characters",Toast.LENGTH_LONG).show();
                } else {
                    // Check if email and password match registered credentials
                    String savedEmail = preferences.getString("email", "null");
                    String savedPass = preferences.getString("pass", "null");

                    if (!studentemail.equals(savedEmail) || !password.equals(savedPass)) {
                        Toast.makeText(MainActivity.this, "Email or password is not saved", Toast.LENGTH_LONG).show();
                    } else {
                        // Add your logic here for sign-in
                        Toast.makeText(MainActivity.this, "Sign-in successful", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(MainActivity.this, myProfile.class);
                        startActivity(intent);
                    }
                }
            }
        });


    }


}